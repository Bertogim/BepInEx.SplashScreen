## Future Ideas
- Lethal Level Loader support

## v1.0.5 (Current version)
- Made readme more clear (No functional changes, but it really needed it)

## v1.0.4
- Fixed a lot of things in the custom loading screen (Idea and help by @glacialstage on discord)

## v1.0.3
- Added loading image support for plugins (Idea and help by @glacialstage on discord)

## v1.0.2
- Fixed errors being thrown to the console.

## v1.0.1
- Fixed the loading window disappearing before the wait time completed.

## v1.0.0
- Initial release of the mod.