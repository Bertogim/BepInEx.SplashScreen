## v1.0.2  
- Fixed errors being thrown to the console.

## v1.0.1  
- Fixed the loading window disappearing before the wait time completed.

## v1.0.0  
- Initial release of the mod.